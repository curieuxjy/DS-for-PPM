import math

a = 1
b = 2

c = math.sqrt(a+b)
print('c = ' + str(c))

ruler1 = '1'
ruler2 = ruler1 + '2' + ruler1

print ('The value of ''ruler2'' is ' + ruler2)