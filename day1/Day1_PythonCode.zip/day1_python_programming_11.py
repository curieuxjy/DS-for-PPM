# Module
#

import myFunctions

x = 1
y = 2

z = myFunctions.sum(x,y);           print('sum: ', z)
z = myFunctions.average(x,y);       print('average: ', z)
z = myFunctions.power(x,y);         print('power: ', z)



#from myFunctions import sum, average, power
#
#x = 1
#y = 2
#
#z = sum(x,y);           print('sum: ', z)
#z = average(x,y);       print('average: ', z)
#z = power(x,y);         print('power: ', z)









